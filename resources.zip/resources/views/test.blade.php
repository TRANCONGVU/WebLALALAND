{{--
<script type="text/javascript" src="{{ asset('js/jquery-3.4.1.min.js') }}"></script>
<script type="text/javascript" src="https://unpkg.com/xzoom/dist/xzoom.min.js"></script>
<link rel="stylesheet" href="{{ asset('css/xzoom.css') }}">
<script>
    $(function () {
        $('.xzoom-1').xzoom();
        $('.xzoom-2').xzoom();
    });
</script>
<div class="zoom-box">
    <img class="xzoom-1" src="{{ asset('images/products/3Hrw_product_--07a6589b.jpg') }}" xoriginal="{{ asset('images/products/3Hrw_product_--07a6589b.jpg') }}" width="500px" />
</div>
<div class="zoom-box">
    <img class="xzoom-2" src="{{ asset('images/products/0xNd_product_-ducngoi.png') }}" xoriginal="{{ asset('images/products/0xNd_product_-ducngoi.png') }}" width="500px" />
</div>--}}
<style>
    .test{
        background-image: url({{ asset('68715781_535093887233294_8157356622797078528_n.png') }});
        background-size: cover;
        background-repeat: no-repeat;
        height: 135px;
        width: 100%;
    }
</style>
<div class="test">dsflksha<br>dsflksha<br>dsflksha<br>dsflksha<br>dsflksha<br>dsflksha<br>dsflksha<br>dsflksha<br>dsflksha<br>dsflksha<br>dsflksha<br>dsflksha<br>dsflksha<br>dsflksha<br>dsflksha<br>dsflksha<br>dsflksha<br>dsflksha<br>dsflksha<br>dsflksha<br>dsflksha<br>dsflksha<br>dsflksha<br></div>