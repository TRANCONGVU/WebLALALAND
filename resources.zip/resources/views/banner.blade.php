	<section class="banner-slider">
		<!-- Start WOWSlider.com BODY section --> <!-- add to the <body> of your page -->
			<div id="wowslider-container1">
			<div class="ws_images"><ul>
				<li><img src="lib/banner-slider/data1/images/banner1.jpg" alt="banner-1" title="banner-1" id="wows1_0"/></li>
				<li><img src="lib/banner-slider/data1/images/banner2.jpg" alt="banner-2" title="banner-2" id="wows1_1"/></li>
				<li><img src="lib/banner-slider/data1/images/banner3.jpg" alt="banner-3" title="banner-3" id="wows1_2"/></li>
				<li><img src="lib/banner-slider/data1/images/banner4.jpg" alt="banner-4" title="banner-4" id="wows1_3"/></a></li>
				<li><img src="lib/banner-slider/data1/images/banner5.jpg" alt="banner-5" title="banner-5" id="wows1_4"/></li>
			</ul></div>
			<div class="ws_bullets"><div>
				<a href="#" title="banner-1"><span><img src="lib/banner-slider/data1/tooltips/banner1.jpg" />1</span></a>
				<a href="#" title="banner-2"><span><img src="lib/banner-slider/data1/tooltips/banner2.jpg" />2</span></a>
				<a href="#" title="banner-3"><span><img src="lib/banner-slider/data1/tooltips/banner3.jpg" />3</span></a>
				<a href="#" title="banner-4"><span><img src="lib/banner-slider/data1/tooltips/banner4.jpg" />4</span></a>
				<a href="#" title="banner-5"><span><img src="lib/banner-slider/data1/tooltips/banner5.jpg" />5</span></a>
			</div>
			<div class="ws_shadow"></div>
			</div>
			<script type="text/javascript" src="lib/banner-slider/engine1/jquery.js"></script>
			<script type="text/javascript" src="lib/banner-slider/engine1/wowslider.js"></script>
			<script type="text/javascript" src="lib/banner-slider/engine1/script.js"></script>
		<!-- End WOWSlider.com BODY section -->
	</section>